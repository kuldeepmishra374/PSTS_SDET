package example.example.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.Test;

import example.example.context.WebDriverContext;
import example.example.factory.PageinstancesFactory;
import example.example.pages.MyntraTest;
import io.github.bonigarcia.wdm.WebDriverManager;

@Test(testName = "Myntra test", description = "Search")
public class TestCase extends BaseTest {
	
	@Test(invocationCount=1)
	public void DemoriaLoginTest() throws InterruptedException {
		WebDriverManager.chromedriver().clearDriverCache().setup(); 
		ChromeOptions ops = new ChromeOptions();
		ops.addArguments("disable-infobars");
		ops.addArguments("--disable-notifications");
		driver = new ChromeDriver(ops); 
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebDriverContext.setDriver(driver);

		driver.get("https://www.myntra.com/men-tshirts");
		MyntraTest myntraTest = PageinstancesFactory.getInstance(MyntraTest.class);
		myntraTest.SearchData();
		
	}
}
