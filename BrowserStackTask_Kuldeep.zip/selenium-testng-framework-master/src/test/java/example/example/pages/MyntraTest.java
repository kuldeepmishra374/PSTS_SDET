package example.example.pages;

import java.util.ArrayList;
import example.example.util.*;
//import jdk.jfr.internal.Logger;

import java.util.Collections;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MyntraTest extends BasePage{
	
	/** The email input. */
	@FindBy(xpath = "//div[@data-reactid='20']//a[contains(text(),'Men')]")
	private WebElement Menu;
	
	@FindBy(xpath = "//a[@data-reactid='345' and contains(text(),'T-Shirts')]")
	private WebElement Submenu;
	
	@FindBy(xpath = "//span[contains(text(),'Brand')]/parent::div/div/span")
	private WebElement Searchicon;
	
	@FindBy(xpath = "//span[contains(text(),'Brand')]/parent::div/div/input")
	private WebElement Searchbox;
	
	@FindBy(xpath = "//*[@id='mountRoot']/div/main/div[3]/div[1]/section/div/div[3]/ul/li[1]/label")
	private WebElement FilterCheckBox;
	
	@FindBy(xpath = "//*[@id='desktopSearchResults']/div[2]/section/ul/li")
	private WebElement ProductList;
	
	

	public MyntraTest(WebDriver driver) {
		super(driver);
	}

	public void SearchData() throws InterruptedException
	{
		Actions action=new Actions(driver);
		//action.moveToElement(Menu).click(Submenu).build().perform();
		//System.out.print(driver.getTitle());
		Searchicon.click();
		Searchbox.sendKeys("van heusen");
		Thread.sleep(10000);
		FilterCheckBox.click();
		Thread.sleep(30000);
		List<WebElement> elementList= driver.findElements(By.xpath("//*[@id='desktopSearchResults']/div[2]/section/ul/li"));
	    
		ArrayList<ArrayList<String>> listOLists = new ArrayList<ArrayList<String>>();
		ArrayList<String> singleList = new ArrayList<String>();
		
		int ctr=0;
		for(WebElement we:elementList)
		{
			  ctr++;
			  String id=we.getAttribute("id");
			  String Name=driver.findElement(By.xpath("//*[@id='"+id+"']/a/div[2]/h4")).getText();
			  Thread.sleep(3000);
			  String BrandName=driver.findElement(By.xpath("//*[@id='"+id+"']/a/div[2]/h3")).getText();
			  Thread.sleep(5000);
			  String Price=driver.findElement(By.xpath("//*[@id='"+id+"']/a/div[2]/div/span/span[2]")).getText(); 
			  Thread.sleep(5000);
			  String Discountpercentage=driver.findElement(By.xpath("//*[@id='"+id+ "']/a/div[2]/div/span[2]")).getText(); 
			  Thread.sleep(1000);
			  String  Link=driver.findElement(By.xpath("//*[@id='"+id+"']/a")).getAttribute("href")
			  ; 
			  String fName=BrandName+" "+Name;
			  System.out.print("Name: "+ fName +","+" Price: "+ Price +","+" Dicount: "+Discountpercentage+","+" Link: "+Link);
			  singleList.add(fName); 
			  singleList.add(Price);
			  singleList.add(Discountpercentage);
			  singleList.add(Link);
			  listOLists.add(singleList);
		   if(ctr==2)
			   break;
		}
	}

}
